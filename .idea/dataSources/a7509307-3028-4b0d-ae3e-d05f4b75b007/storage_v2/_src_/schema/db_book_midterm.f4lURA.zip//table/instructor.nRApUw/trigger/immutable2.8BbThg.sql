create definer = root@localhost trigger immutable2
    before update
    on instructor
    for each row
BEGIN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'IMMUTABLE!!!';
    END;

