create definer = root@localhost view person as
select `db_book_midterm`.`student`.`ID`        AS `ID`,
       `db_book_midterm`.`student`.`name`      AS `name`,
       `db_book_midterm`.`student`.`dept_name` AS `dept_name`,
       'S'                                     AS `S`
from `db_book_midterm`.`student`
union
select `db_book_midterm`.`instructor`.`ID`        AS `ID`,
       `db_book_midterm`.`instructor`.`name`      AS `name`,
       `db_book_midterm`.`instructor`.`dept_name` AS `dept_name`,
       'I'                                        AS `I`
from `db_book_midterm`.`instructor`;

