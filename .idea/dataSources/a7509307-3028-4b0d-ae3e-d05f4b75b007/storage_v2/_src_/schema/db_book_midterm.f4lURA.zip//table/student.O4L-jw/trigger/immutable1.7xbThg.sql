create definer = root@localhost trigger immutable1
    before update
    on student
    for each row
BEGIN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'IMMUTABLE!!!';
    END;

