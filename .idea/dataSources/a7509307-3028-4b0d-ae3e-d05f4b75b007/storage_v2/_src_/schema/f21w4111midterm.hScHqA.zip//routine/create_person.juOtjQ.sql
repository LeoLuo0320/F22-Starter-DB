create
    definer = root@localhost procedure create_person(IN person_name varchar(32), IN dept_name varchar(32),
                                                     IN total_cred decimal(3), IN salary decimal(8, 2),
                                                     OUT ID varchar(5))
BEGIN

    declare bad_person boolean;
    declare new_id varchar(12);

    set bad_person = false;
    set new_id = '00000';

    if (person_name is NULL) or (dept_name is NULL) or (total_cred is NULL and salary is NULL) or (total_cred is not NULL and salary is not NULL) then
        set bad_person = true;
    end if;

    if bad_person is true then
        SIGNAL SQLSTATE '50001'
            SET MESSAGE_TEXT = 'Invalid Person information input';
    end if;

    select CONCAT(max(db_book_midterm.person.ID)+1, '') into new_id from db_book_midterm.person;
    set ID = new_id;

    if total_cred is NULL and salary is not NULL then
        insert into instructor(ID, name, dept_name, salary) VALUES (ID, person_name, dept_name, salary);
    end if;

    if total_cred is not NULL and salary is NULL then
        insert into student(ID, name, dept_name, tot_cred) VALUES (ID, person_name, dept_name, total_cred);
    end if;

END;

